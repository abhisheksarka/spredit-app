angular.module('ms.components.comment', [ 
  'ms.components.comment.lister',
  'ms.components.comment.creator'
]);